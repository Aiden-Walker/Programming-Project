package hashmap.beans;

public class Dado {
    private int numCaras;

    public Dado(int numCaras) {
        this.numCaras = numCaras;
    }
    public int getNumCaras() {
        return numCaras;
    }
}
