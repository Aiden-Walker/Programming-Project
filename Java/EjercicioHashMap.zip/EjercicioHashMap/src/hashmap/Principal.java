package hashmap;

import hashmap.procesos.JuegoDados;

public class Principal {
    public static void main(String[] args) {
        JuegoDados juegoDados = new JuegoDados();
        juegoDados.ejecutar();
    }
}
