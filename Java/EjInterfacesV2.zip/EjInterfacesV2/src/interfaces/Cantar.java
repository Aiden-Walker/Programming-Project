package interfaces;

public interface Cantar {
	public void canta();
	public void canta(String letra);
}
