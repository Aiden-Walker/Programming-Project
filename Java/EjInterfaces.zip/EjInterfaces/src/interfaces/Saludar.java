package interfaces;

public interface Saludar {
	public void saludo();
	public void saludo(String saludo);
	public void saludo(String saludo, String nombre);	
}
