package pr03a;

import java.util.ArrayList;

public class Combates {


    public String enfrentamiento(ArrayList<Nave> imperio,ArrayList<Nave> rebelde) throws ContenedorNaveException {
        
    }
}
