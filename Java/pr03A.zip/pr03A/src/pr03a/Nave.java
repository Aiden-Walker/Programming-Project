package pr03a;

import java.util.Random;

public class Nave {
    public int disparo() {
        Random random = new Random();
        return random.nextInt(5,10);
    }
}
