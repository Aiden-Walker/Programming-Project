package interfaces;

import beans.*;

import java.util.ArrayList;

public class Principal {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Perro perro=new Perro();
		Persona persona=new Persona();
		Gato gato = new Gato();

		ArrayList<Personaje> objetosPersonaje = new ArrayList<Personaje>();

		objetosPersonaje.add(perro);
		objetosPersonaje.add(persona);
		objetosPersonaje.add(gato);

		for (Personaje personaje: objetosPersonaje)
			if ( personaje instanceof Cantar) {
				// Una posibilidad
				Cantar objetoCantor = (Cantar) personaje;
				objetoCantor.canta();

				// Otra posibilidad
				((Cantar) personaje).canta();
			}
			else {
				System.out.println("Noooooo");
			}
	}

}

