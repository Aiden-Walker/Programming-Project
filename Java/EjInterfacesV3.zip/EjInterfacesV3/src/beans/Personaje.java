package beans;

public class Personaje {
}
