package beans;

import interfaces.Cantar;
import interfaces.Saludar;

public class Gato extends Personaje implements  Saludar {

    @Override
    public void saludo() {
        System.out.println("MIAU :)");
    }

    @Override
    public void saludo(String saludo) {
        System.out.println("MIAU "+ saludo);
    }

    @Override
    public void saludo(String saludo, String nombre) {
        System.out.println("Miau "+saludo+" "+nombre);

    }
}
